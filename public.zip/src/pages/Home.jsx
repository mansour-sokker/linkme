import React from "react";
import HeroSection from "../components/home/HeroSection";
import WhatIs from "../components/home/WhatIs";
import HowItWorks from "../components/home/HowItWorks";
import ProfilePreview from "../components/home/ProfilePreview";
import WhyChoose from "../components/home/WhyChoose";

import FinalCTA from "../components/home/FinalCTA";

export default function Home() {
  return (
    <div className="dark:bg-brand-dark bg-white">
      <HeroSection />
      <WhatIs />
      <HowItWorks />
      <ProfilePreview />
      <WhyChoose />

      <FinalCTA />
    </div>
  );
}
