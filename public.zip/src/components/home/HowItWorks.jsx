import React from "react";
import { Smartphone, UserPlus, Share2 } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: <Smartphone size={42} className="text-brand-primary" />,
      title: "Choose Your Card",
      text: "Pick your NFC card design and activate your Dot LinkMe account.",
    },
    {
      icon: <UserPlus size={42} className="text-brand-primary" />,
      title: "Create Your Profile",
      text: "Add your name, bio, photo, and all your social links in minutes.",
    },
    {
      icon: <Share2 size={42} className="text-brand-primary" />,
      title: "Tap & Share",
      text: "Share your digital identity instantly with NFC, QR, or a direct link.",
    },
  ];

  return (
    <section
      data-aos="fade-up"
      className=" py-20 bg-white dark:bg-brand-dark  text-brand-dark dark:text-white"
    >
      <div className="section-shell text-center space-y-12">
        <div>
          <h2 className="text-3xl md:text-4xl font-semibold">
            How <span className="text-brand-primary">Dot LinkMe</span> Works
          </h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto pt-3">
            From card to profile — your identity becomes smarter in seconds.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {steps.map((step, i) => (
            <div
              key={i}
              className="card-glass p-10 space-y-6 hover:shadow-xl transition"
            >
              <div className="mx-auto w-fit">{step.icon}</div>
              <h3 className="text-xl font-semibold">{step.title}</h3>
              <p className="text-gray-600 dark:text-gray-300">{step.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
