import React from "react";
import { Zap, UserCircle, BarChart2 } from "lucide-react";

export default function WhatIs() {
  return (
    <section
      data-aos="fade-up"
      className=" py-20 bg-white dark:bg-brand-dark text-brand-dark dark:text-white"
    >
      <div
        className="section-shell 
text-center space-y-12"
      >
        <div>
          <h2 className="text-3xl md:text-4xl font-semibold">
            What is <span className="text-brand-primary">Dot LinkMe?</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto pt-3">
            A smart NFC-powered identity card that carries your digital profile
            and adapts to your lifestyle.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="card-glass p-8 space-y-4">
            <Zap size={40} className="text-brand-primary" />
            <h3 className="text-xl font-semibold">One Tap Identity</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Share all your contact info instantly using NFC or QR.
            </p>
          </div>

          <div className="card-glass p-8 space-y-4">
            <UserCircle size={40} className="text-brand-primary" />
            <h3 className="text-xl font-semibold">Personal Profile Page</h3>
            <p className="text-gray-600 dark:text-gray-300">
              A beautiful digital profile with your bio, links, and branding.
            </p>
          </div>

          <div className="card-glass p-8 space-y-4">
            <BarChart2 size={40} className="text-brand-primary" />
            <h3 className="text-xl font-semibold">Smart Analytics</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Track visits, clicks, and views in real-time from your dashboard.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
