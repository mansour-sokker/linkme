import React from "react";
import { Link } from "react-router-dom";

export default function FinalCTA() {
  return (
    <section
      data-aos="fade-up"
      className="py-20 bg-brand-primary text-white text-center"
    >
      <div className="section-shell space-y-6">
        <h2 className="text-3xl md:text-4xl font-semibold">
          Start Your Digital Identity Today
        </h2>
        <p className="text-white/90 max-w-2xl mx-auto">
          Upgrade your networking with a smart NFC profile that works
          everywhere.
        </p>
        <Link to="/create-card" className="btn-accent">
          Get Started Now
        </Link>
      </div>
    </section>
  );
}
