import React from "react";
import { Star, RefreshCcw, Leaf, ShieldCheck } from "lucide-react";

export default function WhyChoose() {
  const items = [
    {
      icon: <Star className="text-brand-primary" size={38} />,
      title: "Professional",
      text: "Your identity looks clean, modern, and reliable.",
    },
    {
      icon: <RefreshCcw className="text-brand-primary" size={38} />,
      title: "Always Updated",
      text: "Change your profile anytime without reprinting cards.",
    },
    {
      icon: <Leaf className="text-brand-primary" size={38} />,
      title: "Eco-Friendly",
      text: "One smart card instead of thousands of paper cards.",
    },
    {
      icon: <ShieldCheck className="text-brand-primary" size={38} />,
      title: "Secure",
      text: "Your data stays encrypted and safe.",
    },
  ];

  return (
    <section
      data-aos="fade-up"
      className=" py-20 bg-white dark:bg-brand-dark text-brand-dark dark:text-white"
    >
      <div className="section-shell space-y-12">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-semibold">
            Why Choose <span className="text-brand-primary">Dot LinkMe?</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {items.map((item, i) => (
            <div key={i} className="card-glass p-8 space-y-4 text-center">
              <div className="mx-auto w-fit">{item.icon}</div>
              <h3 className="text-xl font-semibold">{item.title}</h3>
              <p className="text-gray-600 dark:text-gray-300">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
