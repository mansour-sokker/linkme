import React from "react";
import { Link } from "react-router-dom";

export default function ProfilePreview() {
  return (
    <section
      data-aos="fade-up"
      className=" py-24 bg-white dark:bg-brand-dark text-brand-dark dark:text-white"
    >
      <div className="section-shell text-center space-y-12">
        {/* Title */}
        <div>
          <h2 className="text-3xl md:text-4xl font-semibold">
            See Your <span className="text-brand-primary">Smart Profile</span>
          </h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto pt-3">
            A clean digital profile designed to show your identity
            professionally.
          </p>
        </div>

        {/* Preview Card */}
        <div className="flex justify-center">
          <div className="card-glass p-10 w-[350px] space-y-6 text-center">
            <img
              src="/images/avatar-sample.png"
              alt="Profile Avatar"
              className="w-32 h-32 rounded-full mx-auto shadow-md"
            />

            <div>
              <h3 className="text-2xl font-semibold">John Doe</h3>
              <p className="text-gray-600 dark:text-gray-300">UI/UX Designer</p>
            </div>

            <div className="space-y-3">
              <button className="btn-primary w-full">WhatsApp</button>
              <button className="btn-primary w-full">Instagram</button>
              <button className="btn-primary w-full">Portfolio</button>
            </div>
          </div>
        </div>

        {/* CTA */}
        <Link to="/login" className="btn-accent inline-block">
          Try Demo Profile
        </Link>
      </div>
    </section>
  );
}
